package squaregame.squares.noobStomp;

import lombok.Builder;
import org.reflections.vfs.Vfs;
import squaregame.model.Direction;
import squaregame.model.SquareAction;
import squaregame.model.SquareView;
import squaregame.squares.SquareLogic;

import java.util.List;
import java.util.Optional;
import java.util.Random;

public class DefaultSquare extends SquareLogic {
    boolean ne = true;

    public DefaultSquare() {
        super();
    }
    public DefaultSquare(int repForSq2) {
        super();
    }

    /**
     *
     * @param view this is a view of everything the square can see. (view.get(0) = NW, view.get(1) = N,
     *             view.get(2) = NE, etc}. It will always be size 8; It will be null if the square is empty.
     * @return {@link SquareAction} You have 4 different actions a square can take (Move, attack, replicate, wait}
     */
    @Override
    public SquareAction run(SquareView squareView) {
         if (ne) {
             ne = false;
             return replicate(Direction.NE, new Square2());
         } else {
             ne = true;
             return replicate(Direction.SW, new Square3());
         }
    }

    @Override
    public String getSquareName() {
        return "Noob Stomp";
    }
}