package squaregame.squares.noobStomp;

import squaregame.model.Direction;
import squaregame.model.SquareAction;
import squaregame.model.SquareView;
import squaregame.squares.SquareLogic;

import java.util.Random;

public class Square2 extends SquareLogic {
    boolean hasDuplicated = false;
    int counter = 0;
    int rep = 0;
    public Square2() {
        this.counter = 0;
    }

    public Square2(int rep) {
        super();
        this.rep = rep;
    }

    @Override
    public SquareAction run(SquareView view) {
        // duplicate NW, then move!
        final Random random = new Random();
        int boardSize = view.getPlayerAllowedMetadata().getBoardSize();
        if (hasDuplicated) {
            counter++;
            if (counter < (random.nextInt(boardSize / 2))) {
                return SquareAction.move(Direction.E, this);
            } else {
                return SquareAction.attack(Direction.E, new DefaultSquare());
            }
        }
        hasDuplicated = true;
        return replicate(Direction.NW, new DefaultSquare());
    }

    @Override
    public String getSquareName() {
        return null;
    }
}
