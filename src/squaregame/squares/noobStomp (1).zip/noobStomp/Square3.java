package squaregame.squares.noobStomp;

import squaregame.model.Direction;
import squaregame.model.SquareAction;
import squaregame.model.SquareView;
import squaregame.squares.SquareLogic;

import java.util.Random;

public class Square3 extends SquareLogic {
    boolean hasDuplicated = false;
    int counter = 0;

    @Override
    public SquareAction run(SquareView view) {
        final Random random = new Random();
        int boardSize = view.getPlayerAllowedMetadata().getBoardSize();
        if (hasDuplicated) {
            counter++;
            if (counter < (random.nextInt(boardSize / 2))) {
                return SquareAction.move(Direction.W, this);
            } else {
                return SquareAction.attack(Direction.W, new DefaultSquare());
            }
        }
        hasDuplicated = true;
        return replicate(Direction.W, new DefaultSquare());
    }

    @Override
    public String getSquareName() {
        return null;
    }
}
